/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.contactnow;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class BancoSQL {
    // Definir a URL de conexão, usuário e senha do banco de dados
    static String url = "jdbc:postgresql://localhost:5432/ContactNow";
    static String user = "postgres";
    static String senha = "rancho50";

    // Método para inserir um novo contato
    public static void inserirContato(String nome, long numero, String email, String endereco) {

        // SQL com PreparedStatement (usando ? como placeholders para os valores)
        String inserirContatoSQL = "INSERT INTO contato (nome, numero, email, endereco) VALUES (?, ?, ?, ?)";

        // Tentar se conectar ao banco e executar a inserção
        try (Connection con = DriverManager.getConnection(url, user, senha);
             PreparedStatement ps = con.prepareStatement(inserirContatoSQL)) {

            // Substituindo os "?" pelos valores reais
            ps.setString(1, nome);        // Substitui o primeiro "?" pelo valor de 'nome'
            ps.setLong(2, numero);        // Substitui o segundo "?" pelo valor de 'numero'
            ps.setString(3, email);       // Substitui o terceiro "?" pelo valor de 'email'
            ps.setString(4, endereco);    // Substitui o quarto "?" pelo valor de 'endereco'

            // Executa a inserção
            ps.executeUpdate();
            System.out.println("Contato inserido com sucesso!");

        } catch (SQLException e) {
            // Caso ocorra algum erro na execução da query, imprime a exceção
            e.printStackTrace();
        }
    }

    // Método principal para testar a inserção
    public static void main(String[] args) {
        // Definindo valores de exemplo para o contato
        String nome = "Jocimar";
        long numero = 17997941085L;  // Note que estamos passando o número como long
        String email = "jocimarjunior@aluno.utfpr.edu.br";
        String endereco = "Rua Bernardo Seugling, 513";

        // Chamando o método para inserir o contato no banco
        inserirContato(nome, numero, email, endereco);
    }
}
