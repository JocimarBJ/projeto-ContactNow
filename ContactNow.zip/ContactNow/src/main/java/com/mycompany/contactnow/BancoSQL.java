package com.mycompany.contactnow;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class BancoSQL {
    static String url = "jdbc:postgresql://localhost:5432/ContactNow";
    static String driver = "org.postgresql.Driver";
    static String user = "postgres";
    static String senha = "rancho50";
    
    // Método auxiliar para obter conexão
    public static Connection conectar() throws SQLException {
        return DriverManager.getConnection(url, user, senha);
    }
    
    public void criarTabelas() {
        Connection con = null;
        Statement s = null;
        ResultSet rs = null;
        
        String criarUsuarios = "CREATE TABLE IF NOT EXISTS usuario ("
                + "email TEXT PRIMARY KEY,"  // E-mail único e obrigatório
                + "senha TEXT NOT NULL,"      // senha obrigatória
                + "nome TEXT NOT NULL"         // Nome do usuario, obrigatório
                + ")";
        
        String criarContatos = "CREATE TABLE IF NOT EXISTS contato ("
                + "usuario_email TEXT NOT NULL,"  // E-mail único e obrigatório
                + "id SERIAL PRIMARY KEY,"      // ID único e auto-incrementável
                + "nome TEXT NOT NULL,"         // Nome do contato, obrigatório
                + "numero BIGINT NOT NULL,"     // Número de telefone (BIGINT para números grandes)
                + "email TEXT NOT NULL,"  // E-mail único e obrigatório
                + "endereco TEXT," //Endereço do contato
                + "CONSTRAINT fk_usuario_email FOREIGN KEY (usuario_email) REFERENCES usuario(email)"  // Chave estrangeira 
                + ")";
        

        try {
            Class.forName(driver);
            con = conectar();
            s = con.createStatement();
            s.executeUpdate(criarUsuarios);
            s.executeUpdate(criarContatos);
            
            
            System.out.println("Tabelas criadas com sucesso.");
        } catch (ClassNotFoundException | SQLException ex) {
            System.err.println("Erro ao criar as tabelas: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                if (s != null) s.close();
                if (con != null) con.close();
            } catch (SQLException ex) {
                System.err.println("Erro ao fechar recursos: " + ex.getMessage());
            }
        }
    }
    
    // Método para inserir contato, agora incluindo o email do usuário logado
    public static void inserirContato(String nome, long numero, String emailContato, String endereco) {
        // Recupera o email do usuário logado
        String emailUsuario = SessaoUsuario.getInstancia().getEmailUsuarioLogado();
        if (emailUsuario == null) {
            JOptionPane.showMessageDialog(null, "Nenhum usuário logado!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String sql = "INSERT INTO contato (nome, numero, email, endereco, usuario_email) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nome);
            ps.setLong(2, numero);
            ps.setString(3, emailContato);
            ps.setString(4, endereco);
            ps.setString(5, emailUsuario);  // Associando o contato ao usuário logado

            ps.executeUpdate();
            System.out.println("Contato inserido com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao inserir contato: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static void atualizarContato(String nome, long numero, String emailContato, String endereco) {
        String emailUsuario = SessaoUsuario.getInstancia().getEmailUsuarioLogado();
        if (emailUsuario == null) {
            JOptionPane.showMessageDialog(null, "Nenhum usuário logado!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sql = "UPDATE contato SET nome = ?, numero = ?, endereco = ? WHERE email = ? AND usuario_email = ?";

        try (Connection con = conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nome);
            ps.setLong(2, numero);
            ps.setString(3, endereco);
            ps.setString(4, emailContato);
            ps.setString(5, emailUsuario);

            int linhasAfetadas = ps.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Contato atualizado com sucesso!");
            } else {
                System.out.println("Nenhum contato foi atualizado. Verifique se o e-mail do contato está correto.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao atualizar contato: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static void excluirContato(String emailContato) {
        String sql = "DELETE FROM contato WHERE email = ? AND usuario_email = ?";

        try (Connection con = conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, emailContato);
            ps.setString(2, SessaoUsuario.getInstancia().getEmailUsuarioLogado()); 

            int linhasAfetadas = ps.executeUpdate();

            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Contato excluído com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Contato não encontrado!", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir contato: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
