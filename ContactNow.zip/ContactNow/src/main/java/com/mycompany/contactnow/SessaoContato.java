/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.contactnow;

/**
 *
 * @author JocimarBorgesJúnior
 */
public class SessaoContato {
    private static SessaoContato instancia;
    private int idContato;
    private String nome;
    private String numero;
    private String email;
    private String endereco;

    private SessaoContato() {}

    public static SessaoContato getInstancia() {
        if (instancia == null) {
            instancia = new SessaoContato();
        }
        return instancia;
    }

    public void setContato(int idContato, String nome, String numero, String email, String endereco) {
        this.idContato = idContato;
        this.nome = nome;
        this.numero = numero;
        this.email = email;
        this.endereco = endereco;
    }

    public int getIdContato() {
        return idContato;
    }

    public String getNome() {
        return nome;
    }

    public String getNumero() {
        return numero;
    }

    public String getEmail() {
        return email;
    }

    public String getEndereco() {
        return endereco;
    }
}