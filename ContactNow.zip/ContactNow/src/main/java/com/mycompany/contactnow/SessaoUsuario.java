/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.contactnow;

/**
 *
 * @author JocimarBorgesJúnior
 */
public class SessaoUsuario {
    private static SessaoUsuario instancia;
    private String emailUsuarioLogado;

    private SessaoUsuario() {}

    public static SessaoUsuario getInstancia() {
        if (instancia == null) {
            instancia = new SessaoUsuario();
        }
        return instancia;
    }

    public void setEmailUsuarioLogado(String email) {
        this.emailUsuarioLogado = email;
    }

    public String getEmailUsuarioLogado() {
        return emailUsuarioLogado;
    }

    public void limparSessao() {
        emailUsuarioLogado = null;
    }
    
    public boolean estaLogado() {
        return emailUsuarioLogado != null;
    }
}
