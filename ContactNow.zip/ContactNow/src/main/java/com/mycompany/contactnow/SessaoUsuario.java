/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.contactnow;

/**
 *
 * @author JocimarBorgesJúnior
 */
public class SessaoUsuario {
    private static SessaoUsuario instancia;
    private String emailUsuarioLogado;
    private String nomeUsuarioLogado;
    private String senhaUsuarioLogado;

    private SessaoUsuario() {}

    public static SessaoUsuario getInstancia() {
        if (instancia == null) {
            instancia = new SessaoUsuario();
        }
        return instancia;
    }
    
    public void setSenhaUsuarioLogado(String senha) {
        this.senhaUsuarioLogado = senha;
    }

    public String getSenhaUsuarioLogado() {
        return senhaUsuarioLogado;
    }
    
    public void setNomeUsuarioLogado(String nome) {
        this.nomeUsuarioLogado = nome;
    }

    public String getNomeUsuarioLogado() {
        return nomeUsuarioLogado;
    }

    public void setEmailUsuarioLogado(String email) {
        this.emailUsuarioLogado = email;
    }

    public String getEmailUsuarioLogado() {
        return emailUsuarioLogado;
    }

    public void limparSessao() {
        emailUsuarioLogado = null;
        nomeUsuarioLogado = null;
        senhaUsuarioLogado = null;
    }
    
    public boolean estaLogado() {
        return emailUsuarioLogado != null;
    }
}
