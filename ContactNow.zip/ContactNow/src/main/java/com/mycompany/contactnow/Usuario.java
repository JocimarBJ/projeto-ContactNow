/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.contactnow;

/**
 *
 * @author jocim
 */
public class Usuario {

    private String name;
    private String email;
    private String password;
    private boolean statusAuth;
    
    public Usuario(){
        name = "";
        email = "";
        password = "";
        statusAuth = false;
    }
    
        // Método para realizar login
        public boolean realizarLogin(String email, String senha) {
            if (this.email.equals(email) && this.password.equals(senha)) {
                this.statusAuth = true;
                return true; // Login bem-sucedido
            }
            return false; // Falha no login
        }

        // Método para alterar dados da conta
        public void alterarConta(String novoNome, String novoEmail, String novaSenha) {
            this.name = novoNome;
            this.email = novoEmail;
            this.password = novaSenha;
        }

        // Método para excluir a conta
        public void excluirConta() {
            this.name = "";
            this.email = "";
            this.password = "";
            this.statusAuth = false;
        }

        // Método para validar se o e-mail e senha pertencem a uma conta existente
        public boolean validarConta(String email, String senha) {
            return this.email.equals(email) && this.password.equals(senha);
        }

        // Método para validar se a senha é forte
        public boolean validarSenhaForte() {
            // Regras de senha forte: mínimo 8 caracteres, incluindo letra maiúscula, minúscula e número
            return password.length() >= 8 &&
                   password.matches(".*[A-Z].*") &&
                   password.matches(".*[a-z].*") &&
                   password.matches(".*\\d.*");
        }

        // Método para recuperar senha (exemplo simples)
        public String recuperarSenha(String email) {
            if (this.email.equals(email)) {
                return "Sua senha é: " + this.password;
            }
            return "E-mail não encontrado!";
        }

        // Método para retornar informações do usuário
        public String pegarInformacoesUsuario() {
            return "Nome: " + this.name + "\nEmail: " + this.email + "\nStatus: " +
                   (statusAuth ? "Autenticado" : "Não autenticado");
        }
}
