/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.contactnow;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author jocim
 */
public class Usuario {

    private String name;
    private String email;
    private String password;
    private boolean statusAuth;
    
    private static Usuario usuarioAtivo = null; // Usuário logado na sessão
    
    private static final String URL = "jdbc:postgresql://localhost:5432/ContactNow";
    private static final String USER = "postgres";
    private static final String SENHA = "rancho50";
    
    public Usuario(){
        name = "";
        email = "";
        password = "";
        statusAuth = false;
    }
    
    //Métodos Getters
   public String getName(){
       return name;
   }
   
   public String getEmail(){
       return email;
   }
   
   public String getPassword(){
       return password;
   }
   
   public boolean getStatusAuth(){
       return statusAuth;
   }
   
    //Métodos Setters
    public void setName(String name){
        this.name = name;
    }
    
    public void setEmail(String email){
        this.email = email;
    }
    
    public void setPassword(String password){
        this.password = password;
    }
    
    public void setStatusAuth(boolean statusAuth){
        this.statusAuth = statusAuth;
    }
   
    public boolean cadastrarUsuario(String nome, String email, String senha) {
        if (validarConta(email)) { // Verifica se o e-mail já existe
            return false; // Não cadastra se o usuário já existir
        }

        String sql = "INSERT INTO usuario (nome, email, senha) VALUES (?, ?, ?)";

        try (Connection con = DriverManager.getConnection(URL, USER, SENHA);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nome);
            ps.setString(2, email);
            ps.setString(3, senha);

            int linhasAfetadas = ps.executeUpdate();
            return linhasAfetadas > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    
   
        // Método para realizar login
        public static boolean realizarLogin(String email, String senha) {
        String sql = "SELECT nome, senha FROM usuario WHERE email = ?";

        try (Connection con = DriverManager.getConnection(URL, USER, SENHA);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String senhaBanco = rs.getString("senha");
                if (senha.equals(senhaBanco)) {
                    usuarioAtivo = new Usuario(); // Instancia o usuário ativo
                    usuarioAtivo.name = rs.getString("nome");
                    usuarioAtivo.email = email;
                    usuarioAtivo.password = senha;
                    usuarioAtivo.statusAuth = true;
                    return true;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
        
        // Método para validar se a conta existe no banco
    public boolean validarConta(String email) {
        String sql = "SELECT email FROM usuario WHERE email = ?";
        
        try (Connection con = DriverManager.getConnection(URL, USER, SENHA);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            
            return rs.next(); // Retorna true se o email já existir no banco

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean alterarConta(String novoNome, String novoEmail, String novaSenha) {
        if (!statusAuth) {
            return false; // Se o usuário não estiver autenticado, não pode alterar dados
        }

        String sql = "UPDATE usuario SET nome = ?, email = ?, senha = ? WHERE email = ?";

        try (Connection con = DriverManager.getConnection(URL, USER, SENHA);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, novoNome);
            ps.setString(2, novoEmail);
            ps.setString(3, novaSenha);
            ps.setString(4, this.email);

            int linhasAfetadas = ps.executeUpdate();
            if (linhasAfetadas > 0) {
                this.name = novoNome;
                this.email = novoEmail;
                this.password = novaSenha;
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    //Método para excluir conta no banco
    public boolean excluirConta() {
        if (!statusAuth) {
            return false; // Se não estiver logado, não pode excluir conta
        }

        String sql = "DELETE FROM usuario WHERE email = ?";

        try (Connection con = DriverManager.getConnection(URL, USER, SENHA);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, this.email);
            int linhasAfetadas = ps.executeUpdate();

            if (linhasAfetadas > 0) {
                this.name = "";
                this.email = "";
                this.password = "";
                this.statusAuth = false;
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    //Método para recuperar senha
    public static String recuperarSenha(String email) {
        String sql = "SELECT senha FROM usuario WHERE email = ?";
        
        try (Connection con = DriverManager.getConnection(URL, USER, SENHA);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return "Sua senha é: " + rs.getString("senha"); // Isso deveria ser uma recuperação segura
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "E-mail não encontrado!";
    }

    // ✅ Método para obter informações do usuário autenticado
    public String pegarInformacoesUsuario() {
        return "Nome: " + this.name + "\nEmail: " + this.email + "\nStatus: " +
               (statusAuth ? "Autenticado" : "Não autenticado");
    }
}
